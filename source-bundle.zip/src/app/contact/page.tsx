import { T } from '@/components/locale';
import { pageSeo } from '@/content/locales/seo';
import type { Metadata } from 'next';
import { PageHeading } from '@/components/layout';
import { CopyEmail } from '@/components/interaction';
import { profile } from '@/content/profile';
export const metadata: Metadata = { title: { absolute: pageSeo('/contact').title }, description: pageSeo('/contact').description, openGraph: { ...pageSeo('/contact'), locale: 'vi_VN' }, twitter: { ...pageSeo('/contact') } };
export default function Contact() { return <section className="section contact-page"><PageHeading label="A CONVERSATION IS A GOOD BEGINNING" title="Let’s create" text="A film, an image, an idea that won’t leave your head. I’d love to hear about it." /><div className="contact-main"><span className="eyebrow"><T>{"SAY HELLO"}</T></span><a className="email-link" href={`mailto:${profile.email}`}><T>{"letrieuphi.hachi"}</T><br className="email-break" /><T>{".contact@gmail.com "}</T><span>↗</span></a><CopyEmail email={profile.email} /></div><div className="contact-details"><div><span className="eyebrow"><T>{"FIND ME ELSEWHERE"}</T></span><a href={profile.instagram} target="_blank" rel="noreferrer"><T>{"Instagram / @hachi_hichino ↗"}</T></a>{Object.entries(profile.socials).filter(([, url]) => url).map(([name, url]) => <a href={url} key={name} target="_blank" rel="noreferrer">{name} ↗</a>)}</div><div><span className="eyebrow"><T>{"BASED IN"}</T></span><p><T>{"Ho Chi Minh City, Vietnam"}</T></p></div></div><span className="contact-star" aria-hidden="true">✳</span></section>; }
